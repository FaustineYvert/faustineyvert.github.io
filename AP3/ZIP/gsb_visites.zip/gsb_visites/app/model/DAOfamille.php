<?php

namespace App\model;
use PDO;



class DAOfamille extends connexionBDD {    
}

?>